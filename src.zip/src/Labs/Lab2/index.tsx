export default function Lab2() {
	return (
	  <div>
	    <h2> Lab 2</h2>
	  </div>
	);
}