export default function Lab3() {
	return (
	  <div>
	    <h2> Lab 3</h2>
	  </div>
	);
}